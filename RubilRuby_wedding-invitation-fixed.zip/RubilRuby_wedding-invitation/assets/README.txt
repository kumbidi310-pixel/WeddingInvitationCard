Add gallery images here using these filenames:
photo-1.jpg
photo-2.jpg
photo-3.jpg

No cover photo is used on the home page.
For music, add wedding-song.mp3 in this folder.
